$(window).on("load",function () {

    // loading
    // $('.pre-load').stop().animate({opacity:0}, 500, function(){
    //     $('.pre-load').css({'display':'none'});
    //     $('body').css({'overflow-y':'auto'});
    // });

        // fancybox

        $("a.group").fancybox({
            'transitionIn': 'elastic',
            'transitionOut': 'elastic',
            'speedIn': 600,
            'speedOut': 200,
            'overlayShow': false
        });
    
        $('[data-fancybox="gallery"]').fancybox({
            // Options will go here
        });
    
        $('[data-fancybox]').fancybox({
            youtube: {
                controls: 0,
                showinfo: 0
            },
            vimeo: {
                color: 'f00'
            }
        });

    // slider  slider-serves
    $('.slider-customer').owlCarousel({
        loop: true,
        margin: 15,
        rtl: true,
        autoplay: true,
        animate: true,
        animateOut: 'slideOutDown',
        animateIn: 'flipInX',
        navText: [
            "<i class='fa fa-angle-right' aria-hidden='true'></i>",
            "<i class='fa fa-angle-left' aria-hidden='true'></i>"
        ],
        responsive: {
            0: {
                items: 1
            },
            750: {
                items: 1
            },
            1000: {
                items: 1
            }
        }
    });
    $('.slider-serves').owlCarousel({
        loop: true,
        margin: 15,
        rtl: true,
        autoplay: true,
        animate: true,
        navText: [
            "<i class='fa fa-angle-right' aria-hidden='true'></i>",
            "<i class='fa fa-angle-left' aria-hidden='true'></i>"
        ],
        responsive: {
            0: {
                items: 1
            },
            750: {
                items: 2
            },
            1000: {
                items: 3
            }
        }
    });
    
    // $(".click-nav").click(function () {
    //     $(this).toggleClass("active");
    //     $(".header--list__bottom .nav").toggleClass("active");
    // });

    // $(".header--list__bottom .nav ul li ").find("a").click(function() {
    //     var section = $(this).attr("href");
    //     $("html, body").animate({
    //         scrollTop: $(section).offset().top
    //     },1500);
    // });

    });
